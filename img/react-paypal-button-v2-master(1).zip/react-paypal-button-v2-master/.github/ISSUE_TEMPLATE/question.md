---
name: Question
about: Ask your question
title: "[QUESTION]"
labels: ''
assignees: ''

---

**To Do First**
- [ ] Take a look in the [README](https://github.com/Luehang/react-paypal-button-v2/blob/master/README.md)
- [ ] Take a look in the [docs](https://luehangs.site/lue_hang/projects/react-paypal-button-v2)

**Ask your Question**
<!--ask your question-->

**Tags**
<!--add some related tags to your question-->
